from flask import Flask, render_template, redirect, request, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import os

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'clave_secreta_segura')

# Configuración de la base de datos: usar DATABASE_URL si está definida, si no usar SQLite local
db_uri = os.getenv('DATABASE_URL', 'sqlite:///tutoriza_flat.db')
app.config['SQLALCHEMY_DATABASE_URI'] = db_uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# crear tablas (SQLite por defecto)
# importar el módulo models para registrar clases y user_loader (evita importar nombres a nivel módulo)
import models

# exponer modelos en el espacio de nombres local para uso en las rutas
User = models.User
Asesoria = models.Asesoria

# crear tablas (SQLite por defecto) después de importar los modelos
db.create_all()

# -------------------------------
# RUTAS DE AUTENTICACIÓN
# -------------------------------
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        email = request.form['email']
        password = request.form['password']
        confirm = request.form['confirm']

        # Validaciones básicas
        if len(nombre) < 2 or len(apellido) < 2:
            flash("Nombre y apellido deben tener al menos 2 caracteres", "danger")
            return redirect(url_for('register'))

        if password != confirm:
            flash("Las contraseñas no coinciden", "danger")
            return redirect(url_for('register'))

        existing = User.query.filter_by(email=email).first()
        if existing:
            flash("El email ya está registrado", "danger")
            return redirect(url_for('register'))

        hashed = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(nombre=nombre, apellido=apellido, email=email, password=hashed)
        db.session.add(user)
        db.session.commit()
        flash("Registro exitoso, ahora puedes iniciar sesión", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash("Credenciales incorrectas", "danger")
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Sesión cerrada correctamente", "info")
    return redirect(url_for('login'))

# -------------------------------
# DASHBOARD
# -------------------------------
@app.route('/dashboard')
@login_required
def dashboard():
    asesorias = Asesoria.query.order_by(Asesoria.fecha).all()
    return render_template('dashboard.html', user=current_user, asesorias=asesorias)

# Rutas para CRUD de asesorías (simplificadas)
@app.route('/asesoria/nueva', methods=['GET', 'POST'])
@login_required
def nueva_asesoria():
    if request.method == 'POST':
        tema = request.form['tema']
        fecha = request.form['fecha']
        duracion = int(request.form['duracion'])
        notas = request.form.get('notas', '')
        tutor_id = request.form.get('tutor') or None
        ases = Asesoria(tema=tema, fecha=fecha, duracion=duracion, notas=notas, solicitante_id=current_user.id, tutor_id=tutor_id)
        db.session.add(ases)
        db.session.commit()
        flash('Asesoría creada', 'success')
        return redirect(url_for('dashboard'))
    users = User.query.filter(User.id != current_user.id).all()
    return render_template('nueva_asesoria.html', users=users)

@app.route('/asesoria/<int:ases_id>')
def ver_asesoria(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    users = User.query.filter(User.id != ases.solicitante_id).all()
    return render_template('ver_asesoria.html', ases=ases, usuarios=users)

@app.route('/asesoria/<int:ases_id>/editar', methods=['GET', 'POST'])
@login_required
def editar_asesoria(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    if ases.solicitante_id != current_user.id:
        flash('No tienes permiso para editar esta asesoría.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        ases.tema = request.form['tema']
        ases.fecha = request.form['fecha']
        ases.duracion = int(request.form['duracion'])
        ases.notas = request.form.get('notas', '')
        ases.tutor_id = request.form.get('tutor') or None
        db.session.commit()
        flash('Asesoría actualizada', 'success')
        return redirect(url_for('dashboard'))
    users = User.query.filter(User.id != current_user.id).all()
    return render_template('editar_asesoria.html', ases=ases, users=users)

@app.route('/asesoria/<int:ases_id>/borrar', methods=['POST'])
@login_required
def borrar_asesoria(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    if ases.solicitante_id != current_user.id:
        flash('No tienes permiso para eliminar esta asesoría.', 'danger')
        return redirect(url_for('dashboard'))
    db.session.delete(ases)
    db.session.commit()
    flash('Asesoría eliminada', 'success')
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
