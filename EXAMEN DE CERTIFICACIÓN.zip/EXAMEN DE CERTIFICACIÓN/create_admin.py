from app import create_app, db, bcrypt
from app.models import User

app = create_app()

with app.app_context():
    email = 'admin@tutoriza.local'
    if not User.query.filter_by(email=email).first():
        pw = bcrypt.generate_password_hash('adminpass').decode('utf-8')
        u = User(nombre='Admin', apellido='Tutoriza', email=email, password_hash=pw, is_admin=True)
        db.session.add(u)
        db.session.commit()
        print('Admin creado:', email)
    else:
        print('Admin ya existe')
