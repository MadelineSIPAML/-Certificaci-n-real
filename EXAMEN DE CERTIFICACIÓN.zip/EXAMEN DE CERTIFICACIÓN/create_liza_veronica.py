#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para crear el usuario "Liza Veronica" como tutora
"""
import pymysql
from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()

def create_liza_veronica():
    """Crea el usuario Liza Veronica como tutora"""
    print("=" * 60)
    print("CREAR TUTORA: Liza Veronica")
    print("=" * 60)
    
    try:
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='admin4B',
            database='tutoriza_db',
            charset='utf8mb4'
        )
        cursor = conn.cursor()
        
        # Verificar si ya existe
        cursor.execute("SELECT id, is_tutor FROM user WHERE email = %s", ('liza.veronica@tutoriza.com',))
        existing = cursor.fetchone()
        
        if existing:
            user_id, is_tutor = existing
            if is_tutor:
                print(f"\n✓ Liza Veronica ya existe y YA ES TUTORA (ID: {user_id})")
            else:
                print(f"\n⚠️  Liza Veronica existe pero NO es tutora (ID: {user_id})")
                print("   Actualizando para marcarla como tutora...")
                cursor.execute("UPDATE user SET is_tutor = 1 WHERE id = %s", (user_id,))
                conn.commit()
                print("✓ Liza Veronica ahora ES TUTORA")
        else:
            print("\n📝 Creando nueva usuaria: Liza Veronica")
            
            # Crear hash de contraseña
            password = "tutora123"
            password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
            
            # Insertar usuario
            cursor.execute("""
                INSERT INTO user (nombre, apellido, email, password_hash, is_admin, is_tutor, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
            """, ('Liza', 'Veronica', 'liza.veronica@tutoriza.com', password_hash, 0, 1))
            
            conn.commit()
            user_id = cursor.lastrowid
            
            print(f"✓ Usuaria creada exitosamente (ID: {user_id})")
            print("\n📋 DATOS DE ACCESO:")
            print(f"   Email: liza.veronica@tutoriza.com")
            print(f"   Contraseña: {password}")
            print(f"   Es tutora: SÍ ✓")
        
        # Mostrar todos los tutores actuales
        cursor.execute("""
            SELECT id, nombre, apellido, email 
            FROM user 
            WHERE is_tutor = 1 
            ORDER BY nombre
        """)
        tutores = cursor.fetchall()
        
        print(f"\n👨‍🏫 TUTORES DISPONIBLES ({len(tutores)}):")
        print("-" * 60)
        for t_id, nombre, apellido, email in tutores:
            print(f"  {t_id}. {nombre} {apellido} ({email})")
        
        print("\n✓ Liza Veronica ahora aparecerá en los selectores de tutor")
        print("✓ Puedes asignarla al crear o editar asesorías")
        
        conn.close()
        print("\n" + "=" * 60)
        print("✓ ¡PROCESO COMPLETADO!")
        print("=" * 60)
        return True
        
    except pymysql.Error as e:
        print(f"\n✗ Error de base de datos: {e}")
        return False
    except Exception as e:
        print(f"\n✗ Error: {e}")
        return False

if __name__ == '__main__':
    create_liza_veronica()
