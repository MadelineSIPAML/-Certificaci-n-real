from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_user, logout_user, login_required, current_user
from datetime import date
from . import db, bcrypt
from .models import User, Asesoria
from .forms import RegisterForm, LoginForm, AsesoriaForm, TutorForm, ChangeTutorForm
from werkzeug.urls import url_parse
from flask import current_app as app


# Rutas:


@app.route('/')
@login_required
def index():
    # Dashboard: mostrar solo asesorías futuras (no mostrar pasadas)
    hoy = date.today()
    asesorias = Asesoria.query.filter(Asesoria.fecha >= hoy).order_by(Asesoria.fecha).all()
    return render_template('index.html', asesorias=asesorias)


def _require_admin():
    if not current_user.is_admin:
        abort(403)


@app.route('/tutores/nuevo', methods=['GET', 'POST'])
@login_required
def agregar_tutor():
    _require_admin()
    form = TutorForm()
    if form.validate_on_submit():
        if not form.password.data:
            flash('La contraseña es obligatoria al crear un nuevo usuario.', 'danger')
            return render_template('agregar_tutor.html', form=form)
        pw_hash = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(
            nombre=form.nombre.data.strip(),
            apellido=form.apellido.data.strip(),
            email=form.email.data.strip(),
            password_hash=pw_hash,
            is_tutor=form.is_tutor.data
        )
        db.session.add(user)
        db.session.commit()
        tipo = 'tutor' if form.is_tutor.data else 'usuario'
        flash(f'{tipo.capitalize()} creado correctamente.', 'success')
        return redirect(url_for('listar_tutores'))
    return render_template('agregar_tutor.html', form=form)


@app.route('/tutores')
@login_required
def listar_tutores():
    _require_admin()
    tutors = User.query.order_by(User.nombre).all()
    return render_template('tutores_list.html', tutors=tutors)


@app.route('/tutores/editar/<int:user_id>', methods=['GET', 'POST'])
@login_required
def editar_tutor(user_id):
    _require_admin()
    user = User.query.get_or_404(user_id)
    form = TutorForm(obj=user)
    if form.validate_on_submit():
        user.nombre = form.nombre.data.strip()
        user.apellido = form.apellido.data.strip()
        user.email = form.email.data.strip()
        user.is_tutor = form.is_tutor.data
        if form.password.data:
            user.password_hash = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        db.session.commit()
        flash('Usuario actualizado.', 'success')
        return redirect(url_for('listar_tutores'))
    return render_template('editar_tutor.html', form=form, user=user)


@app.route('/tutores/borrar/<int:user_id>', methods=['POST'])
@login_required
def borrar_tutor(user_id):
    _require_admin()
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash('No puedes eliminar tu propia cuenta.', 'danger')
        return redirect(url_for('listar_tutores'))
    db.session.delete(user)
    db.session.commit()
    flash('Tutor eliminado.', 'success')
    return redirect(url_for('listar_tutores'))
# Gestión de tutores removida del proyecto.


@app.route('/health')
def health():
    return 'ok', 200


@app.route('/register', methods=['GET', 'POST'])
def auth_register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegisterForm()
    if form.validate_on_submit():
        pw_hash = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(
            nombre=form.nombre.data.strip(),
            apellido=form.apellido.data.strip(),
            email=form.email.data.strip(),
            password_hash=pw_hash
        )
        db.session.add(user)
        db.session.commit()
        flash('Registro exitoso. Puedes iniciar sesión.', 'success')
        return redirect(url_for('auth_login'))
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def auth_login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.strip()).first()
        if user and bcrypt.check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash('Inicio de sesión correcto.', 'success')
            next_page = request.args.get('next')
            if not next_page or url_parse(next_page).netloc != '':
                next_page = url_for('index')
            return redirect(next_page)
        else:
            flash('Credenciales inválidas.', 'danger')
    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def auth_logout():
    logout_user()
    flash('Has cerrado sesión.', 'info')
    return redirect(url_for('index'))


@app.route('/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo():
    form = AsesoriaForm()
    # poblar choices para el select de tutor (solo usuarios marcados como tutores)
    tutors = User.query.filter(User.id != current_user.id, User.is_tutor == True).order_by(User.nombre).all()
    form.tutor.choices = [(0, 'Sin tutor')] + [(u.id, f"{u.nombre} {u.apellido}") for u in tutors]
    if form.validate_on_submit():
        if form.fecha.data < date.today():
            flash('No puedes crear una asesoría con fecha en el pasado.', 'danger')
            return render_template('nuevo.html', form=form)
        ases = Asesoria(
            tema=form.tema.data.strip(),
            fecha=form.fecha.data,
            duracion=form.duracion.data,
            notas=form.notas.data.strip(),
            creador_id=current_user.id,
            tutor_id=form.tutor.data if form.tutor.data else None
        )
        db.session.add(ases)
        db.session.commit()
        flash('Asesoría creada.', 'success')
        return redirect(url_for('index'))
    return render_template('nuevo.html', form=form)


@app.route('/ver/<int:ases_id>', methods=['GET', 'POST'])
def ver(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    # pasar ChangeTutorForm para renderizar selector en la vista
    form = ChangeTutorForm()
    tutors = User.query.filter(User.id != ases.creador_id, User.is_tutor == True).order_by(User.nombre).all()
    form.tutor.choices = [(0, 'Sin tutor')] + [(u.id, f"{u.nombre} {u.apellido}") for u in tutors]
    form.tutor.data = ases.tutor_id or 0
    return render_template('ver.html', ases=ases, change_form=form)


@app.route('/editar/<int:ases_id>', methods=['GET', 'POST'])
@login_required
def editar(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    if ases.creador_id != current_user.id:
        abort(403)
    form = AsesoriaForm(obj=ases)
    # poblar choices y preseleccionar el tutor actual (solo usuarios marcados como tutores)
    tutors = User.query.filter(User.id != current_user.id, User.is_tutor == True).order_by(User.nombre).all()
    form.tutor.choices = [(u.id, f"{u.nombre} {u.apellido}") for u in tutors]
    # si el tutor actual no está en choices, agregarlo temporalmente
    if ases.tutor_id and ases.tutor_id not in [c[0] for c in form.tutor.choices]:
        t = User.query.get(ases.tutor_id)
        if t:
            form.tutor.choices.insert(0, (t.id, f"{t.nombre} {t.apellido}"))
    form.tutor.data = ases.tutor_id or (form.tutor.choices[0][0] if form.tutor.choices else None)
    if request.method == 'GET':
        pass

    if form.validate_on_submit():
        if form.fecha.data < date.today():
            flash('La fecha no puede estar en el pasado.', 'danger')
            return render_template('editar.html', form=form, ases=ases)
        ases.tema = form.tema.data.strip()
        ases.fecha = form.fecha.data
        ases.duracion = form.duracion.data
        ases.notas = form.notas.data.strip()
        ases.tutor_id = form.tutor.data if form.tutor.data else None
        db.session.commit()
        flash('Asesoría actualizada.', 'success')
        return redirect(url_for('index'))
    return render_template('editar.html', form=form, ases=ases)


@app.route('/borrar/<int:ases_id>', methods=['POST'])
@login_required
def borrar(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    if ases.creador_id != current_user.id:
        abort(403)
    db.session.delete(ases)
    db.session.commit()
    flash('Asesoría eliminada.', 'success')
    return redirect(url_for('index'))


@app.route('/ver/<int:ases_id>/asignar_tutor', methods=['POST'])
@login_required
def asignar_tutor(ases_id):
    ases = Asesoria.query.get_or_404(ases_id)
    # solo el creador puede asignar o cambiar el tutor
    if ases.creador_id != current_user.id:
        abort(403)
    form = ChangeTutorForm()
    # choices: solo usuarios marcados como tutores, excepto el creador de la asesoría
    tutors = User.query.filter(User.id != ases.creador_id, User.is_tutor == True).order_by(User.nombre).all()
    form.tutor.choices = [(0, 'Sin tutor')] + [(u.id, f"{u.nombre} {u.apellido}") for u in tutors]
    if form.validate_on_submit():
        ases.tutor_id = form.tutor.data if form.tutor.data and form.tutor.data != 0 else None
        db.session.commit()
        flash('Tutor actualizado.', 'success')
    else:
        flash('Error al asignar tutor.', 'danger')
    return redirect(url_for('ver', ases_id=ases.id))
