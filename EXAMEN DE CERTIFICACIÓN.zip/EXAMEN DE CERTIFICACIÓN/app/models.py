from . import db, login_manager
from flask_login import UserMixin
from datetime import datetime
from sqlalchemy import func


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_tutor = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=func.now())

    # relaciones
    # relaciones
    # especificamos la foreign key usada para esta relación para evitar ambigüedades
    asesorias_creadas = db.relationship('Asesoria', foreign_keys='Asesoria.creador_id', backref='creador', lazy=True)

    def __repr__(self):
        return f"<User {self.email}>"

class Asesoria(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tema = db.Column(db.String(120), nullable=False)
    fecha = db.Column(db.Date, nullable=False)
    duracion = db.Column(db.Integer, nullable=False)
    notas = db.Column(db.String(250))
    creador_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    tutor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=func.now())

    # nota: tutor será referencia a usuario (uno de la misma tabla user)
    tutor = db.relationship('User', foreign_keys=[tutor_id], uselist=False)

    def __repr__(self):
        return f"<Asesoria {self.tema} {self.fecha}>"
