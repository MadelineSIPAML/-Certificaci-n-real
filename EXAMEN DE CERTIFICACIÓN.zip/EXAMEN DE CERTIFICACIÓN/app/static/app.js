document.addEventListener('DOMContentLoaded', function(){
  // Reveal elements with class .reveal
  document.querySelectorAll('.reveal').forEach(function(el, i){
    setTimeout(function(){ el.classList.add('animate-in') }, 80 * i);
  });

  // Auto-dismiss flash messages
  const flashes = document.querySelectorAll('.flashes .flash');
  flashes.forEach(function(f, i){
    setTimeout(function(){ f.classList.add('hide') }, 4200 + (i*300));
  });

  // Small interaction: floating label helper (optional)
  document.querySelectorAll('input, textarea, select').forEach(function(inp){
    inp.addEventListener('focus', function(){ inp.classList.add('focused') });
    inp.addEventListener('blur', function(){ if(!inp.value) inp.classList.remove('focused') });
  });
});
