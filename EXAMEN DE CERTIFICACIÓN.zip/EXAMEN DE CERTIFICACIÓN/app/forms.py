from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, TextAreaField, DateField, SelectField, BooleanField
from wtforms.validators import DataRequired, Email, EqualTo, Length, NumberRange, ValidationError
from .models import User
from . import db


def only_letters(form, field):
    if not field.data.isalpha():
        raise ValidationError("Sólo se permiten letras.")


class RegisterForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=2), only_letters])
    apellido = StringField('Apellido', validators=[DataRequired(), Length(min=2), only_letters])
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired(), Length(min=6)])
    confirm = PasswordField('Confirmar Contraseña', validators=[DataRequired(), EqualTo('password', message='Las contraseñas deben coincidir.')])
    submit = SubmitField('Registrar')

    def validate_email(self, email):
        if User.query.filter_by(email=email.data).first():
            raise ValidationError("El email ya está registrado.")


class LoginForm(FlaskForm):
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Iniciar Sesión')


class AsesoriaForm(FlaskForm):
    tema = StringField('Tema', validators=[DataRequired(), Length(min=1)])
    fecha = DateField('Fecha', validators=[DataRequired()], format='%Y-%m-%d')
    duracion = IntegerField('Duración (horas)', validators=[DataRequired(), NumberRange(min=1, max=8)])
    notas = TextAreaField('Notas', validators=[Length(max=50)])
    # tutor can be optional (0 means 'Sin tutor')
    tutor = SelectField('Tutor', coerce=int, validators=[])
    submit = SubmitField('Guardar')

    # Validación adicional: fecha no puede ser en el pasado (se hará en routes con comparación de hoy)


class TutorForm(FlaskForm):
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=2)])
    apellido = StringField('Apellido', validators=[DataRequired(), Length(min=2)])
    email = StringField('E-mail', validators=[DataRequired(), Email()])
    password = PasswordField('Contraseña', validators=[Length(min=6)])
    is_tutor = BooleanField('¿Es tutor?', default=True)
    submit = SubmitField('Guardar')

    def validate_email(self, email):
        if User.query.filter_by(email=email.data).first():
            raise ValidationError('El email ya está registrado.')


class ChangeTutorForm(FlaskForm):
    # allow selecting 0 for 'Sin tutor'
    tutor = SelectField('Tutor', coerce=int, validators=[])
    submit = SubmitField('Cambiar Tutor')


