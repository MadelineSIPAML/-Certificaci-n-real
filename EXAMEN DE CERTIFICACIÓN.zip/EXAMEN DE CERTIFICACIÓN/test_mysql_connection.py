#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para verificar la conexión MySQL
"""
from mysqlconnection import connectToMySQL

def test_connection():
    print("=" * 70)
    print("PRUEBA DE CONEXIÓN MySQL")
    print("=" * 70)
    
    try:
        # Conectar a la base de datos
        print("\n🔌 Conectando a tutoriza_db...")
        mysql = connectToMySQL('tutoriza_db')
        print("✓ Conexión establecida exitosamente\n")
        
        # Probar consulta SELECT
        print("📋 Consultando tutoras...")
        tutoras = mysql.query_db("SELECT nombre, apellido, email, is_tutor FROM user WHERE is_tutor = 1")
        
        print(f"\n👩‍🏫 TUTORAS ENCONTRADAS: {len(tutoras)}")
        print("-" * 70)
        
        for tutora in tutoras:
            print(f"  • {tutora['nombre']} {tutora['apellido']}")
            print(f"    Email: {tutora['email']}")
            print(f"    Es tutora: {'SÍ' if tutora['is_tutor'] else 'NO'}")
            print()
        
        # Probar contar usuarios
        total_users = mysql.query_db("SELECT COUNT(*) as total FROM user")
        print(f"📊 Total de usuarios en el sistema: {total_users[0]['total']}")
        
        # Probar contar asesorías
        total_asesorias = mysql.query_db("SELECT COUNT(*) as total FROM asesoria")
        print(f"📚 Total de asesorías: {total_asesorias[0]['total']}")
        
        print("\n" + "=" * 70)
        print("✅ CONEXIÓN MySQL FUNCIONANDO CORRECTAMENTE")
        print("=" * 70)
        return True
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\n" + "=" * 70)
        print("✗ HAY PROBLEMAS CON LA CONEXIÓN")
        print("=" * 70)
        return False

if __name__ == '__main__':
    test_connection()
