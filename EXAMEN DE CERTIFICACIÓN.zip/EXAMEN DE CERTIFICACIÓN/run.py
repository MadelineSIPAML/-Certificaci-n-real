from app import create_app

app = create_app()

if __name__ == "__main__":
    # Ejecutar en localhost en el puerto 8050 sin reloader para evitar procesos duplicados
    app.run(host='127.0.0.1', port=8050, debug=True, use_reloader=False)
