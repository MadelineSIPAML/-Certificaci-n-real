#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para crear la base de datos MySQL y las tablas necesarias
"""
import pymysql
from app import create_app, db

def setup_database():
    """Crea la base de datos si no existe"""
    print("Conectando a MySQL...")
    try:
        # Conectar a MySQL sin especificar base de datos
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='admin4B',
            charset='utf8mb4'
        )
        cursor = conn.cursor()
        
        # Crear la base de datos si no existe
        print("Creando base de datos tutoriza_db...")
        cursor.execute('CREATE DATABASE IF NOT EXISTS tutoriza_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci')
        
        # Verificar que se creó
        cursor.execute("SHOW DATABASES LIKE 'tutoriza_db'")
        result = cursor.fetchone()
        if result:
            print(f"✓ Base de datos creada exitosamente: {result[0]}")
        
        conn.close()
        print("✓ Conexión cerrada")
        
    except pymysql.Error as e:
        print(f"✗ Error al crear la base de datos: {e}")
        return False
    
    # Ahora crear las tablas usando Flask-SQLAlchemy
    print("\nCreando tablas...")
    try:
        app = create_app()
        with app.app_context():
            db.create_all()
            print("✓ Tablas creadas exitosamente")
            
            # Mostrar las tablas creadas
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            tables = inspector.get_table_names()
            print(f"✓ Tablas en la base de datos: {', '.join(tables)}")
            
    except Exception as e:
        print(f"✗ Error al crear las tablas: {e}")
        return False
    
    print("\n✓ ¡Configuración de base de datos completada!")
    return True

if __name__ == '__main__':
    setup_database()
