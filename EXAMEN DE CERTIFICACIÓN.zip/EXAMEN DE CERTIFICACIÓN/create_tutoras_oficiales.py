#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para crear las tutoras: Liza Molina y Veronica Espinoza
"""
import pymysql
from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()

def create_tutoras():
    """Crea las dos tutoras oficiales"""
    print("=" * 70)
    print("CREAR TUTORAS OFICIALES DEL SISTEMA")
    print("=" * 70)
    
    tutoras = [
        {
            'nombre': 'Liza',
            'apellido': 'Molina',
            'email': 'liza.molina@sip.cl',
            'password': 'LizaMolina2025!'
        },
        {
            'nombre': 'Veronica',
            'apellido': 'Espinoza',
            'email': 'veronica.espinoza@sip.cl',
            'password': 'VeronicaEspinoza2025!'
        }
    ]
    
    try:
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='admin4B',
            database='tutoriza_db',
            charset='utf8mb4'
        )
        cursor = conn.cursor()
        
        # Primero, limpiar tutoras anteriores si existen
        print("\n🧹 Limpiando tutoras de prueba...")
        cursor.execute("DELETE FROM user WHERE email = 'liza.veronica@tutoriza.com'")
        deleted = cursor.rowcount
        if deleted > 0:
            print(f"   ✓ Eliminado {deleted} usuario(s) de prueba")
        
        conn.commit()
        
        print("\n📝 Creando tutoras oficiales...\n")
        
        for tutora in tutoras:
            # Verificar si ya existe
            cursor.execute("SELECT id, is_tutor FROM user WHERE email = %s", (tutora['email'],))
            existing = cursor.fetchone()
            
            if existing:
                user_id, is_tutor = existing
                if is_tutor:
                    print(f"✓ {tutora['nombre']} {tutora['apellido']} ya existe y ES TUTORA (ID: {user_id})")
                else:
                    cursor.execute("UPDATE user SET is_tutor = 1 WHERE id = %s", (user_id,))
                    conn.commit()
                    print(f"✓ {tutora['nombre']} {tutora['apellido']} actualizada como TUTORA (ID: {user_id})")
            else:
                # Crear hash de contraseña
                password_hash = bcrypt.generate_password_hash(tutora['password']).decode('utf-8')
                
                # Insertar usuario
                cursor.execute("""
                    INSERT INTO user (nombre, apellido, email, password_hash, is_admin, is_tutor, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, NOW())
                """, (tutora['nombre'], tutora['apellido'], tutora['email'], password_hash, 0, 1))
                
                conn.commit()
                user_id = cursor.lastrowid
                print(f"✓ {tutora['nombre']} {tutora['apellido']} creada exitosamente (ID: {user_id})")
        
        # Mostrar credenciales
        print("\n" + "=" * 70)
        print("📋 CREDENCIALES DE ACCESO:")
        print("=" * 70)
        
        for i, tutora in enumerate(tutoras, 1):
            print(f"\n{i}. {tutora['nombre']} {tutora['apellido']}")
            print(f"   📧 Email: {tutora['email']}")
            print(f"   🔑 Contraseña: {tutora['password']}")
            print(f"   👩‍🏫 Rol: TUTORA ✓")
        
        # Mostrar todos los tutores
        cursor.execute("""
            SELECT id, nombre, apellido, email 
            FROM user 
            WHERE is_tutor = 1 
            ORDER BY nombre
        """)
        tutores = cursor.fetchall()
        
        print("\n" + "=" * 70)
        print(f"👨‍🏫 TUTORAS DISPONIBLES EN EL SISTEMA ({len(tutores)}):")
        print("=" * 70)
        for t_id, nombre, apellido, email in tutores:
            print(f"  • {nombre} {apellido} ({email})")
        
        print("\n✅ Las tutoras ahora aparecerán en los selectores de tutor")
        print("✅ Solo ellas pueden ser asignadas como tutoras en las asesorías")
        
        conn.close()
        print("\n" + "=" * 70)
        print("✓ ¡PROCESO COMPLETADO!")
        print("=" * 70)
        return True
        
    except pymysql.Error as e:
        print(f"\n✗ Error de base de datos: {e}")
        return False
    except Exception as e:
        print(f"\n✗ Error: {e}")
        return False

if __name__ == '__main__':
    create_tutoras()
