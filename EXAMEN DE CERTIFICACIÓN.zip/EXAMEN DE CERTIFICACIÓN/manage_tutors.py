#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para marcar usuarios existentes como tutores
"""
import pymysql

def list_and_update_tutors():
    """Lista usuarios y permite marcarlos como tutores"""
    print("=" * 60)
    print("GESTIÓN DE TUTORES - Script de Actualización")
    print("=" * 60)
    
    try:
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='admin4B',
            database='tutoriza_db',
            charset='utf8mb4'
        )
        cursor = conn.cursor()
        
        # Listar todos los usuarios
        cursor.execute("""
            SELECT id, nombre, apellido, email, is_admin, is_tutor 
            FROM user 
            ORDER BY nombre
        """)
        users = cursor.fetchall()
        
        if not users:
            print("\n❌ No hay usuarios en la base de datos")
            print("   Registra usuarios primero en /register")
            return
        
        print(f"\n📋 USUARIOS REGISTRADOS ({len(users)}):\n")
        print(f"{'ID':<5} {'Nombre':<30} {'Email':<30} {'Admin':<8} {'Tutor':<8}")
        print("-" * 90)
        
        for user in users:
            user_id, nombre, apellido, email, is_admin, is_tutor = user
            nombre_completo = f"{nombre} {apellido}"
            admin_mark = "✓" if is_admin else "-"
            tutor_mark = "✓" if is_tutor else "-"
            print(f"{user_id:<5} {nombre_completo:<30} {email:<30} {admin_mark:<8} {tutor_mark:<8}")
        
        print("\n" + "=" * 60)
        print("OPCIONES:")
        print("  1. Marcar usuario(s) como tutor")
        print("  2. Quitar rol de tutor a usuario(s)")
        print("  3. Ver solo tutores actuales")
        print("  0. Salir")
        print("=" * 60)
        
        opcion = input("\nSelecciona una opción (0-3): ").strip()
        
        if opcion == "1":
            ids = input("\nIngresa ID(s) de usuarios a marcar como tutores (separados por coma): ")
            ids_list = [int(x.strip()) for x in ids.split(",") if x.strip().isdigit()]
            
            if ids_list:
                placeholders = ','.join(['%s'] * len(ids_list))
                cursor.execute(f"UPDATE user SET is_tutor = 1 WHERE id IN ({placeholders})", ids_list)
                conn.commit()
                print(f"\n✓ {cursor.rowcount} usuario(s) marcado(s) como tutor")
                
                # Mostrar usuarios actualizados
                cursor.execute(f"SELECT nombre, apellido FROM user WHERE id IN ({placeholders})", ids_list)
                updated = cursor.fetchall()
                for nombre, apellido in updated:
                    print(f"  • {nombre} {apellido}")
            else:
                print("\n❌ No se ingresaron IDs válidos")
        
        elif opcion == "2":
            ids = input("\nIngresa ID(s) de usuarios para quitar rol de tutor (separados por coma): ")
            ids_list = [int(x.strip()) for x in ids.split(",") if x.strip().isdigit()]
            
            if ids_list:
                placeholders = ','.join(['%s'] * len(ids_list))
                cursor.execute(f"UPDATE user SET is_tutor = 0 WHERE id IN ({placeholders})", ids_list)
                conn.commit()
                print(f"\n✓ {cursor.rowcount} usuario(s) ya no es tutor")
                
                # Mostrar usuarios actualizados
                cursor.execute(f"SELECT nombre, apellido FROM user WHERE id IN ({placeholders})", ids_list)
                updated = cursor.fetchall()
                for nombre, apellido in updated:
                    print(f"  • {nombre} {apellido}")
            else:
                print("\n❌ No se ingresaron IDs válidos")
        
        elif opcion == "3":
            cursor.execute("""
                SELECT id, nombre, apellido, email 
                FROM user 
                WHERE is_tutor = 1 
                ORDER BY nombre
            """)
            tutores = cursor.fetchall()
            
            if tutores:
                print(f"\n👨‍🏫 TUTORES ACTIVOS ({len(tutores)}):\n")
                print(f"{'ID':<5} {'Nombre':<30} {'Email':<30}")
                print("-" * 70)
                for t_id, nombre, apellido, email in tutores:
                    nombre_completo = f"{nombre} {apellido}"
                    print(f"{t_id:<5} {nombre_completo:<30} {email:<30}")
            else:
                print("\n❌ No hay tutores marcados")
                print("   Usa la opción 1 para marcar usuarios como tutores")
        
        elif opcion == "0":
            print("\n👋 ¡Hasta luego!")
        else:
            print("\n❌ Opción inválida")
        
        conn.close()
        
    except pymysql.Error as e:
        print(f"\n✗ Error de base de datos: {e}")
    except ValueError:
        print("\n❌ IDs inválidos. Ingresa solo números separados por coma")
    except Exception as e:
        print(f"\n✗ Error: {e}")

if __name__ == '__main__':
    list_and_update_tutors()
