from app import create_app, db
from sqlalchemy import inspect, text

app = create_app()

with app.app_context():
    engine = db.engine
    insp = inspect(engine)
    table_name = 'user'
    try:
        cols = [c['name'] for c in insp.get_columns(table_name)]
    except Exception as e:
        print(f"Error inspeccionando la tabla {table_name}: {e}")
        raise

    if 'is_admin' in cols:
        print('La columna is_admin ya existe en la tabla user.')
    else:
        print('Añadiendo columna is_admin a la tabla user...')
        # MySQL tinyint(1) para booleano
        sql = f"ALTER TABLE `{table_name}` ADD COLUMN is_admin TINYINT(1) NOT NULL DEFAULT 0;"
        try:
            with engine.connect() as conn:
                conn.execute(text(sql))
                conn.commit()
            print('Columna is_admin añadida correctamente.')
        except Exception as e:
            print('Error al añadir columna is_admin:', e)
            raise
