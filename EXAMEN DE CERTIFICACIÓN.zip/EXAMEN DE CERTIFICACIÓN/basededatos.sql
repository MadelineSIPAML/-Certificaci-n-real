-- basededatos.sql
-- Esquema SQL para la aplicación Tutoriza (compatible MySQL)
-- Crea las tablas principales: user y asesoria

-- Elimina tablas si existen (orden pensado para MySQL)
DROP TABLE IF EXISTS `asesoria`;
DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `apellido` VARCHAR(50) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `is_admin` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_email` (`email`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `asesoria` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `tema` VARCHAR(120) NOT NULL,
  `fecha` DATE NOT NULL,
  `duracion` INT NOT NULL,
  `notas` VARCHAR(250),
  `creador_id` INT NOT NULL,
  `tutor_id` INT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_asesoria_creador` (`creador_id`),
  KEY `idx_asesoria_tutor` (`tutor_id`),
  CONSTRAINT `fk_asesoria_creador_user` FOREIGN KEY (`creador_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_asesoria_tutor_user` FOREIGN KEY (`tutor_id`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ejemplos de inserciones (opcional)
-- NOTA: la contraseña debe ser un hash bcrypt; se recomienda usar el script Python `create_admin.py`
-- para crear un usuario admin con hash correcto en vez de insertar en crudo.
--
-- INSERT INTO `user` (nombre, apellido, email, password_hash, is_admin)
-- VALUES ('Admin', 'Tutoriza', 'admin@tutoriza.local', '<bcrypt-hash-aqui>', 1);

-- Instrucciones:
-- MySQL: crea la base de datos (por ejemplo tutoriza_db) y luego importa:
--   mysql -u <usuario> -p -h <host> tutoriza_db < basededatos.sql

-- SQLite: si usas SQLite con SQLAlchemy el archivo no es necesario porque la app
-- crea las tablas automáticamente (db.create_all()). Si quieres obtener un dump
-- desde la base SQLite creada por la app, puedes ejecutar:
--   sqlite3 tutoriza.db .schema > esquema.sql

-- Alternativa para crear admin:
--   python create_admin.py
#👩‍🏫 TUTORAS DEL SISTEMA:
#1. Liza Molina
#📧 Email: liza.molina@sip.cl
#🔑 Contraseña: LizaMolina2025!
#✅ Es tutora: SÍ
#2. Veronica Espinoza
#📧 Email: veronica.espinoza@sip.cl
#🔑 Contraseña: VeronicaEspinoza2025!
#✅ Es tutora: SÍ

from mysqlconnection import connectToMySQL

# Conectar a la base de datos tutoriza_db
mysql = connectToMySQL('tutoriza_db')

# Ejemplo: Consulta SELECT
usuarios = mysql.query_db("SELECT * FROM user WHERE is_tutor = 1")
print(usuarios)

# Ejemplo: INSERT
query = "INSERT INTO user (nombre, apellido, email, password_hash, is_tutor) VALUES (%s, %s, %s, %s, %s)"
data = ('Juan', 'Pérez', 'juan@ejemplo.com', 'hash123', 1)
nuevo_id = mysql.query_db(query, data)
print(f"Usuario creado con ID: {nuevo_id}")

# Ejemplo: UPDATE
query = "UPDATE user SET is_tutor = %s WHERE email = %s"
data = (1, 'usuario@ejemplo.com')
mysql.query_db(query, data)

# Ejemplo: DELETE
query = "DELETE FROM user WHERE id = %s"
data = (5,)
mysql.query_db(query, data)

