#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script para agregar el campo is_tutor a la tabla user
"""
import pymysql

def add_is_tutor_column():
    """Agrega la columna is_tutor a la tabla user si no existe"""
    print("Conectando a MySQL...")
    try:
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='admin4B',
            database='tutoriza_db',
            charset='utf8mb4'
        )
        cursor = conn.cursor()
        
        # Verificar si la columna ya existe
        cursor.execute("""
            SELECT COUNT(*) 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'tutoriza_db' 
            AND TABLE_NAME = 'user' 
            AND COLUMN_NAME = 'is_tutor'
        """)
        exists = cursor.fetchone()[0]
        
        if exists:
            print("✓ La columna 'is_tutor' ya existe en la tabla user")
        else:
            print("Agregando columna 'is_tutor' a la tabla user...")
            cursor.execute("""
                ALTER TABLE user 
                ADD COLUMN is_tutor TINYINT(1) DEFAULT 0 AFTER is_admin
            """)
            conn.commit()
            print("✓ Columna 'is_tutor' agregada exitosamente")
        
        # Mostrar estructura de la tabla
        cursor.execute("DESCRIBE user")
        columns = cursor.fetchall()
        print("\n✓ Estructura actual de la tabla 'user':")
        for col in columns:
            print(f"  - {col[0]}: {col[1]}")
        
        conn.close()
        print("\n✓ ¡Migración completada!")
        return True
        
    except pymysql.Error as e:
        print(f"✗ Error: {e}")
        return False

if __name__ == '__main__':
    add_is_tutor_column()
