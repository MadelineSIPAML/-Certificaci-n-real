# Sistema de Tutores - Guía de Uso

## ✅ Cambios Implementados

He añadido un sistema completo para gestionar tutores basado en los usuarios registrados.

### 🔄 Qué cambió:

1. **Nueva columna en la base de datos**
   - Agregué `is_tutor` (boolean) a la tabla `user`
   - Por defecto es `False` para usuarios normales
   - Se puede activar/desactivar desde la gestión de usuarios

2. **Actualización del modelo User**
   - Campo `is_tutor` agregado
   - Permite marcar cualquier usuario como tutor

3. **Formulario actualizado**
   - Checkbox "¿Es tutor?" en crear/editar usuario
   - Contraseña opcional al editar (solo obligatoria al crear)

4. **Filtros en selectores**
   - Solo usuarios con `is_tutor=True` aparecen en los selectores de tutor
   - Se aplica en: crear asesoría, editar asesoría, cambiar tutor

---

## 📋 Cómo Funciona

### Flujo Completo:

1. **Usuario se registra normalmente** (`/register`)
   - Se crea con `is_tutor=False` por defecto
   - Es un usuario normal que puede crear asesorías

2. **Admin marca al usuario como tutor** (`/tutores/editar/<id>`)
   - El admin accede a "Gestión de Tutores"
   - Edita el usuario y marca el checkbox "¿Es tutor?"
   - Guarda los cambios

3. **Usuario ahora aparece como opción de tutor**
   - Al crear/editar asesorías, este usuario aparece en el selector
   - Puede ser asignado como tutor de cualquier asesoría

---

## 🎯 Casos de Uso

### Caso 1: Crear un nuevo tutor desde cero
```
1. Admin → /tutores/nuevo
2. Completa: nombre, apellido, email, contraseña
3. Marca checkbox "¿Es tutor?"
4. Click en "Guardar"
5. El usuario es creado y puede ser asignado como tutor
```

### Caso 2: Convertir usuario existente en tutor
```
1. Usuario se registra normalmente (no es tutor)
2. Admin → /tutores
3. Admin busca al usuario y click en "Editar"
4. Admin marca checkbox "¿Es tutor?"
5. Click en "Guardar"
6. Ahora el usuario aparece en los selectores de tutor
```

### Caso 3: Remover a alguien como tutor
```
1. Admin → /tutores
2. Click en "Editar" del usuario
3. Desmarca checkbox "¿Es tutor?"
4. Click en "Guardar"
5. El usuario ya no aparece en selectores de tutor
6. Las asesorías donde era tutor mantienen la relación
```

---

## 🔐 Permisos

### Admin puede:
- ✅ Ver todos los usuarios (`/tutores`)
- ✅ Crear nuevos usuarios (`/tutores/nuevo`)
- ✅ Editar cualquier usuario (`/tutores/editar/<id>`)
- ✅ Marcar/desmarcar usuarios como tutores
- ✅ Borrar usuarios (`/tutores/borrar/<id>`)

### Usuario normal puede:
- ✅ Registrarse (`/register`)
- ✅ Crear asesorías (`/nuevo`)
- ✅ Ver solo tutores activos en los selectores
- ❌ No puede gestionar usuarios
- ❌ No puede marcarse a sí mismo como tutor

---

## 📊 Base de Datos

### Estructura de la tabla `user`:
```sql
CREATE TABLE user (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  apellido VARCHAR(50) NOT NULL,
  email VARCHAR(120) UNIQUE NOT NULL,
  password_hash VARCHAR(128) NOT NULL,
  is_admin TINYINT(1) DEFAULT 0,
  is_tutor TINYINT(1) DEFAULT 0,  -- ← NUEVO
  created_at DATETIME DEFAULT NOW()
);
```

### Script de migración ejecutado:
```sql
ALTER TABLE user 
ADD COLUMN is_tutor TINYINT(1) DEFAULT 0 AFTER is_admin;
```

---

## 🚀 Cómo Usar

### 1. Aplicar la migración (ya ejecutada)
```powershell
python add_is_tutor_column.py
```

### 2. Iniciar la aplicación
```powershell
.\run_mysql.ps1
```
O manualmente:
```powershell
$env:DATABASE_URL = "mysql+pymysql://root:admin4B@localhost:3306/tutoriza_db"
python run.py
```

### 3. Crear el primer admin (si no existe)
```powershell
python create_admin.py
```

### 4. Acceder a la aplicación
- URL: http://127.0.0.1:8050
- Login como admin
- Ir a "Gestión de Tutores"
- Crear o editar usuarios y marcarlos como tutores

---

## 💡 Ejemplos Prácticos

### Ejemplo 1: Registrar usuario y convertirlo en tutor
```
1. María se registra en /register
   - Email: maria@ejemplo.com
   - Se crea con is_tutor=False

2. Admin hace login
3. Admin va a /tutores
4. Admin busca a María y click "Editar"
5. Admin marca "¿Es tutor?" ✓
6. Guarda

7. Ahora al crear una asesoría:
   - En el selector "Tutor" aparece: María
   - Puede ser asignada como tutora
```

### Ejemplo 2: Crear tutor directamente
```
1. Admin hace login
2. Admin va a /tutores/nuevo
3. Completa:
   - Nombre: Juan
   - Apellido: Pérez
   - Email: juan@ejemplo.com
   - Contraseña: tutor123
   - ¿Es tutor? ✓
4. Click "Guardar"

5. Juan puede:
   - Hacer login con juan@ejemplo.com / tutor123
   - Crear sus propias asesorías
   - Ser asignado como tutor de otras asesorías
```

---

## 🔍 Consultas SQL Útiles

### Ver todos los tutores:
```sql
SELECT id, nombre, apellido, email, is_tutor 
FROM user 
WHERE is_tutor = 1;
```

### Ver todos los usuarios:
```sql
SELECT id, nombre, apellido, email, is_admin, is_tutor 
FROM user 
ORDER BY nombre;
```

### Marcar usuario como tutor manualmente:
```sql
UPDATE user 
SET is_tutor = 1 
WHERE email = 'usuario@ejemplo.com';
```

### Ver asesorías con sus tutores:
```sql
SELECT 
  a.id,
  a.tema,
  a.fecha,
  c.nombre as creador,
  t.nombre as tutor
FROM asesoria a
JOIN user c ON a.creador_id = c.id
LEFT JOIN user t ON a.tutor_id = t.id;
```

---

## 📝 Archivos Modificados

1. **`app/models.py`**
   - Agregado campo `is_tutor` al modelo User

2. **`app/forms.py`**
   - Agregado `BooleanField` para is_tutor en TutorForm
   - Contraseña ahora es opcional (solo obligatoria al crear)

3. **`app/routes.py`**
   - Actualizado `agregar_tutor()` para guardar is_tutor
   - Actualizado `editar_tutor()` para modificar is_tutor
   - Filtros en selectores: solo usuarios con is_tutor=True
   - Aplicado en rutas: `nuevo()`, `ver()`, `editar()`, `asignar_tutor()`

4. **`app/templates/agregar_tutor.html`**
   - Agregado checkbox "¿Es tutor?"

5. **`app/templates/editar_tutor.html`**
   - Agregado checkbox "¿Es tutor?"
   - Nota sobre contraseña opcional

6. **`add_is_tutor_column.py`** (nuevo)
   - Script para migrar la base de datos

---

## ✅ Ventajas de Este Diseño

1. **Flexibilidad**
   - Cualquier usuario puede ser tutor
   - No hay usuarios "separados"
   - Un tutor también puede crear asesorías

2. **Simplicidad**
   - Un solo campo boolean
   - Fácil de activar/desactivar
   - No requiere tablas adicionales

3. **Escalabilidad**
   - Fácil agregar más campos (especialidad, horario, etc.)
   - Se puede extender para múltiples roles

4. **Mantenibilidad**
   - Código limpio y organizado
   - Filtros centralizados
   - Fácil de entender

---

## 🎉 Resumen

✅ **Sistema de tutores implementado completamente**
✅ **Migración de base de datos ejecutada**
✅ **Formularios actualizados**
✅ **Filtros aplicados en todos los selectores**
✅ **Sin errores de sintaxis**

**¡Tu aplicación está lista para gestionar tutores!**

---

*Fecha: 7 de octubre de 2025*
