# Script PowerShell para ejecutar la aplicación Tutoriza con MySQL
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Iniciando aplicación Tutoriza con MySQL" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Configurar variable de entorno para MySQL
$env:DATABASE_URL = "mysql+pymysql://root:admin4B@localhost:3306/tutoriza_db"
Write-Host "✓ Variable DATABASE_URL configurada para MySQL" -ForegroundColor Green

# Activar entorno virtual
& "C:\Users\AML-lVB\Documents\EXAMEN DE CERTIFICACIÓN\venv\Scripts\Activate.ps1"
Write-Host "✓ Entorno virtual activado" -ForegroundColor Green

# Mostrar información
Write-Host ""
Write-Host "Iniciando servidor en http://127.0.0.1:8050" -ForegroundColor Yellow
Write-Host "Presiona Ctrl+C para detener el servidor" -ForegroundColor Yellow
Write-Host ""

# Ejecutar la aplicación
python "C:\Users\AML-lVB\Documents\EXAMEN DE CERTIFICACIÓN\run.py"
